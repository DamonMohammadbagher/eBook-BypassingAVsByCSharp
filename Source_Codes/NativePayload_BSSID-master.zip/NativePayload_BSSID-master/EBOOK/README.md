# Simple Linux Scripts for Transferring/Exfiltration DATA via BSSID and Wireless Traffic

For More Information and Use These Scripts Step by Step Please Read This Article :

Article : https://www.peerlyst.com/posts/linux-systems-and-data-transferring-exfiltration-via-bssid-by-wireless-traffic-damon-mohammadbagher

Related Article : https://www.peerlyst.com/posts/transferring-backdoor-payloads-with-bssid-by-wireless-traffic-damon-mohammadbagher

