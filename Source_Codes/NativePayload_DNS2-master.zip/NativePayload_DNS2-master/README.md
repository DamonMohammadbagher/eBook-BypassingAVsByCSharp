# NativePayload_DNS2 
 C# Code for transferring Backdoor Payloads by DNS Traffic (A Records) and Bypassing Anti-viruses 
 C# Code for Exfiltration and Uploading DATA to DNS Server via (PTR Records).
 
 Published by Damon Mohammadbagher (Sep-Oct 2017)
 
 C# Code (ver 2.0) : https://github.com/DamonMohammadbagher/NativePayload_DNS2
 
 link1 Article Published (A Records) : https://www.peerlyst.com/posts/exfiltration-technique-by-dns-traffic-a-records-damon-mohammadbagher
 
 link2 Article Published (Exfiltration and PTR Records) : https://www.peerlyst.com/posts/exfiltrationand-uploading-data-by-dns-traffic-ptr-records-damon-mohammadbagher
 
 Note: for using LogReader.exe tool and Exfiltration via DNS PTR Records by NativePayload_DNS2.exe tool you should read "Link2" Article. (recommended)
 
 Note: how to compile C# codes syntax :
 
 Developer Command Prompt for VS2015 : c:\\> csc.exe  /out:NativePayload_DNS2.exe   NativePayload_DNS2.cs
 
 Developer Command Prompt for VS2015 : c:\\> csc.exe  /out:LogReader.exe   LogReader.cs
 
 Video 1 (A Records only) :  https://www.youtube.com/watch?v=B-vR7jKXyts
 
 Video 2 (PTR Records) (New) :  https://www.youtube.com/watch?v=AgDbcC9kgcg
 
 Article is from Ebook "Bypassing Anti Viruses by C#.NET Programming" , Chapter 4 : Exfiltration/Transferring Technique by DNS Traffic (A Records) and Chapter 5 Exfiltration and Uploading DATA by DNS Traffic (PTR Records).
 
 Supporting .NET 2.0 , 3.0 , 3.5 , 4.0 (Only)
 
