# Course : Bypassing Anti Viruses by C#.NET Programming

Part 1 (C#.NET Tricks and Techniques) , Chapter 13 : C# e[X]tension Method (X Technique) and bypassing Anti-viruses

eBook chapter 13 , PDF Download : https://github.com/DamonMohammadbagher/eBook-BypassingAVsByCSharp/tree/master/CH13

Related Video : 

# New-Code : AVAST Bypassed by "X" Technique "NativePayload_Reverse_tcpx.cs"
  ![](https://github.com/DamonMohammadbagher/NativePayload_Reverse_tcp/blob/master/Ebook%20-%20Chapter%2013%20-%20C%23%20%5BX%5D%20Technique%20%26%20bypassing%20Anti-viruses/Pictures/av4-1.png)

# Old-Code : "NativePayload_SimpleReverse_tcp.cs" Code Detected by AVAST 
  ![](https://github.com/DamonMohammadbagher/NativePayload_Reverse_tcp/blob/master/Ebook%20-%20Chapter%2013%20-%20C%23%20%5BX%5D%20Technique%20%26%20bypassing%20Anti-viruses/Pictures/detected.png)
