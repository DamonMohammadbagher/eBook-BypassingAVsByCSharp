# Course : Bypassing Anti Viruses by C#.NET Programming

Part 1 (C#.NET Tricks and Techniques) , Chapter 2 : Making Encrypted Meterpreter Payload by C#.NET

NEW and Source Code (only)

Note: "PDF File" For This Chapter Will Publish by "Peerlyst Ebook" Soon , For More Information Please Visit This Link : https://www.peerlyst.com/posts/ebook-initiative-the-white-hat-hackers-guide-to-hacking-and-pentesting-for-the-common-good-peerlyst (Chapter 13 - Evading security appliances and software "Damon Mohammadbagher").


eBook chapter 2 , PDF Download : https://github.com/DamonMohammadbagher/eBook-BypassingAVsByCSharp/tree/master/CH2

Related Video : https://youtu.be/j6pwSemHfTY




