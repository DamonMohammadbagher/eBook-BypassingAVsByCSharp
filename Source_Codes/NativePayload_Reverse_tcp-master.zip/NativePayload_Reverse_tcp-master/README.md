[![Stage](https://img.shields.io/badge/Release-STABLE-brightgreen.svg)]()


# NativePayload_Reverse_tcp
Meterpreter Encrypted Payload by C#.Net

Note : I made this Backdoor source code for describe Antiviruses vulnerability only. 

 You can use Meterpreter Encrypted Payloads with this C# Source code
 
 Publisher and Author: Damon mohammadbagher
 
 Email :  Damonmohammadbagher@gmail.com
 
 Step 1 : you should Encrypt your Msfvenom Payload with EncryptMaker tool 
 
 Step 2 : you can hardcode your encrypted Payload in this code by value "Payload_Encrypted"
 
 or you can use command prompt argument for importing Encrypted Payload to this code (Safe)
 
 for more information visit these link 
 
 step by step and for more information Please visit this link : https://www.linkedin.com/pulse/bypass-all-anti-viruses-encrypted-payloads-c-damon-mohammadbagher

Antivirus and Signature Based Detection Methods Doesn't Work for Defense
https://www.linkedin.com/pulse/antivirus-signature-based-detection-methods-doesnt-mohammadbagher?trk=pulse_spock-articles

Related Link:

Bypassing Anti-viruses with transfer Backdoor Payloads by DNS traffic

https://www.linkedin.com/pulse/bypassing-anti-viruses-transfer-backdoor-payloads-dns-mohammadbagher
https://github.com/DamonMohammadbagher/NativePayload_DNS

Ver 2 : test without AV
  ![](https://github.com/DamonMohammadbagher/NativePayload_Reverse_tcp/blob/master/NativePayload_Reverse_tcp2.png)

Ver 2 : test with AV (comodo bypassed) 
  ![](https://github.com/DamonMohammadbagher/NativePayload_Reverse_tcp/blob/master/1.png)
  
Old Article (v2): Antivirus and Signature Based Detection Methods Doesn't Work for Defense
https://www.linkedin.com/pulse/antivirus-signature-based-detection-methods-doesnt-mohammadbagher?trk=pulse_spock-articles

<p><a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FDamonMohammadbgher%2F/NativePayload_Reverse_tcp"/></a></p>
 
