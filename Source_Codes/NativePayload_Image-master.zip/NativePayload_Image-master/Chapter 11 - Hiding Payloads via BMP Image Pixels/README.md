# Course : Bypassing Anti Viruses by C#.NET Programming

Part 2 (Infil/Exfiltration/Transferring Techniques by C#)  , Chapter 11 : Hiding Payloads via BMP Image Pixels

eBook : Bypassing Anti Viruses by C#.NET Programming

eBook chapter 11 , PDF Download : https://github.com/DamonMohammadbagher/eBook-BypassingAVsByCSharp/tree/master/CH11

Related Video : 

Video 1 Script (Step by step) : https://www.youtube.com/watch?v=D5tfh23vIOQ

Video 2 : Chat/Text-Messaging Mode and Transferring Commands via BMP Images (Step by step)

Video 2 : Linux Script Code : https://www.youtube.com/watch?v=2n6ZLbJxlkw



Warning :Don't Use "www.virustotal.com" or something like that , Never Ever ;D

Recommended:

STEP 1 : Use each AV one by one in your LAB .

STEP 2 : after "AV Signature Database Updated" your Internet Connection should be "Disconnect" .

STEP 3 : Now you can Copy and Paste your C# code to your Virtual Machine for test .

# NativePayload_Image.sh  help :

Note : this Script Tested by Kali Linux (only)

for more information Please use this syntax "./NativePayload_Image.sh  help" or for Using this tool Step by step please read this Chapter-11(Part2) PDF file . (Recommended)

(Recommended) : Chapter-11(Part2) PDF file link : https://github.com/DamonMohammadbagher/eBook-BypassingAVsByCSharp/blob/master/CH11/Bypassing%20Anti%20Viruses%20by%20C%23.NET%20Programming%20Chapter%2011-Part2.pdf
